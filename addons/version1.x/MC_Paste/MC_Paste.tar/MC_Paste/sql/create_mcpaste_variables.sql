CREATE TABLE IF NOT EXISTS `mcpaste_variables` (
  `name` varchar(191) NOT NULL default '',
  `value` longtext NULL default '',
  PRIMARY KEY  (`name`)
)
  DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;